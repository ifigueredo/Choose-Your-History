use CHOSE_YOUR_STORY;


insert into ADVENTURE (Name,Description,id_characters,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values('La historia de Jordi','No se',1,USER(),sysdate(),null,null);


