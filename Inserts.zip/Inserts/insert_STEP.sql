USE CHOSE_YOUR_STORY;

# STEP
#La Historia de Jordi

Insert into STEP (Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values('Primer Paso','%personaje% está en el inicio del Bosque Maldito,
 Donde se encuentra 3 caminos ... ¿por donde irá?',1,false,user(),sysdate(),null,null); 

Insert into STEP (Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values ('Paso2(1)','Efectivamente, el puente es el cámino mas corto, 
no contabas con que el puente se descolgaría, 
Y no sobrevives a la caida. FIN',1,false,user(),sysdate(),null,null);

Insert into STEP(Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values ('Paso2(2)','Sorteando los peligros, llegas de noche al centro 
del bosque, y ves clavada en un cadaver una 
espada llameante que te susurra al oido... 
¿Que haces?',1,false,user(),sysdate(),null,null);

Insert into STEP (Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values ('Paso2(3)','%personaje% está en el inicio del Bosque Maldito,
 Donde se encuentra 3 caminos ... ¿por donde irá?',1,false,user(),sysdate(),null,null);

Insert into STEP (Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values ('Paso3(1)','Matas a toda tu gente, e invadido por la tristeza, decides arrancarte la vida. FIN',1,false,
user(),sysdate(),null,null);


Insert into STEP (Name,Description,id_adventures,final_step,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values ('Paso3(2)','Mas fuerte que nunca, decides que es el momento de erradicar el mal junto 
A tu nueva aliada, y te embarcas en una nueva aventura. FIN.',1,true,user(),sysdate(),null,null);




 

