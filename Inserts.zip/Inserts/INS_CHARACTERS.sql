USE CHOSE_YOUR_STORY;

#CHARACTERS

INSERT INTO CHARACTERS(Name,Description,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion)VALUES('Jordi','Un professor de programacion y un maestro del BrowlStars',user(),sysdate(),null,null);

INSERT INTO CHARACTERS(Name,Description,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion)VALUES('Alicia','Una niña intrepida de cabello rubio dorado',user(),sysdate(),null,null);

