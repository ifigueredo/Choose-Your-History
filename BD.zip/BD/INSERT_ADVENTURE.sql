use CHOSE_YOUR_STORY;

insert into ADVENTURE values(1,'La historia de Jordi','No se',1,USER(),sysdate(),null,null);

insert into ADVENTURE (Name,Description,id_characters,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values('La Busqueda de la Espada','Un heroe se envarca en una aventura en busca de una legendaria espada para que le ayude a erradicar el mal',1,user(),SYSDATE(),NULL,NULL); 

insert into ADVENTURE(Name,Description,id_characters,usuariocreacion,fechacreacion,usuariomodificacion,fechamodificacion) values('Alicia en el país de las maravillas','Unete a la aventura de la pequeña Alicia en una historia llena de recuerdos y guiños a otros mundos',2,user(),SYSDATE(),NULL,NULL); 

 

